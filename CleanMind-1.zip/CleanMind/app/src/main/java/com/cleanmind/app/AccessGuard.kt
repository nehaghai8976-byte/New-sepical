package com.cleanmind.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.SystemClock
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Accessibility ko khud ON/OFF karta hai. Iske liye ek baar ADB se WRITE_SECURE_SETTINGS permission deni padti hai:
 * adb shell pm grant com.cleanmind.app android.permission.WRITE_SECURE_SETTINGS
 *
 * 1) Lock ke time Accessibility kisi ne band ki to wapas ON.
 * 2) Payment app (GPay/Paytm) khulte hi 3 min ke liye OFF, phir khud ON.
 */
object AccessGuard {
    private const val PAY_WINDOW_MS = 3 * 60_000L
    private const val MAX_PAY_WINDOWS_PER_DAY = 5

    private fun p(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)
    private fun boot(c: Context) = Settings.Global.getInt(c.contentResolver, Settings.Global.BOOT_COUNT, -1)
    private fun me(c: Context) = "${c.packageName}/${BlockerService::class.java.name}"

    fun canWrite(c: Context) =
        c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    fun payWindowLeft(c: Context): Long {
        val s = p(c)
        var left = s.getLong("payWall", 0) - System.currentTimeMillis()
        if (s.getInt("payBoot", -2) == boot(c)) {
            left = maxOf(left, s.getLong("payElapsed", 0) - SystemClock.elapsedRealtime())
        }
        return maxOf(left, 0)
    }

    private fun dayKey() = "payw_" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    private fun enabledList(c: Context): List<String> =
        (Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .split(":").filter { it.isNotEmpty() }

    /** 0 = kuch nahi hua, 1 = payment window shuru (Accessibility OFF), 2 = aaj ki limit khatam. */
    fun startPayWindow(c: Context): Int {
        try {
            if (!canWrite(c)) return 0
            if (payWindowLeft(c) > 0) return 0
            val s = p(c)
            if (Lock.isLocked(c)) {
                val used = s.getInt(dayKey(), 0)
                if (used >= MAX_PAY_WINDOWS_PER_DAY) return 2
                s.edit().putInt(dayKey(), used + 1).apply()
            }
            s.edit()
                .putLong("payWall", System.currentTimeMillis() + PAY_WINDOW_MS)
                .putLong("payElapsed", SystemClock.elapsedRealtime() + PAY_WINDOW_MS)
                .putInt("payBoot", boot(c))
                .putBoolean("pay_restore", true)
                .apply()
            // Window khatam hone par alarm se wapas ON
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(c, 7, Intent(c, PayWindowReceiver::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + PAY_WINDOW_MS + 2000, pi)
            // Accessibility OFF
            val rest = enabledList(c).filter { it != me(c) }.joinToString(":")
            Settings.Secure.putString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, rest)
            return 1
        } catch (_: Exception) {
            return 0
        }
    }

    /** Zaroorat ho to Accessibility wapas ON. */
    fun ensure(c: Context) {
        try {
            if (!canWrite(c)) return
            if (payWindowLeft(c) > 0) return
            val s = p(c)
            val restore = s.getBoolean("pay_restore", false)
            if (!(restore || Lock.isStrict(c))) return
            if (!enabledList(c).contains(me(c))) {
                val updated = (enabledList(c) + me(c)).joinToString(":")
                Settings.Secure.putString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, updated)
                Settings.Secure.putInt(c.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            }
            if (restore) s.edit().putBoolean("pay_restore", false).apply()
        } catch (_: Exception) {}
    }
}

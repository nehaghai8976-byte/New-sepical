package com.cleanmind.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Roz kitni baar block hua uska hisaab (Analytics ke liye). */
object Stats {
    private fun p(c: Context) = c.getSharedPreferences("stats", Context.MODE_PRIVATE)

    fun hit(c: Context) {
        val k = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        p(c).edit().putInt(k, p(c).getInt(k, 0) + 1).apply()
    }

    /** Purane se aaj tak, 7 din. */
    fun last7(c: Context): List<Pair<String, Int>> {
        val out = ArrayList<Pair<String, Int>>()
        val df = SimpleDateFormat("yyyyMMdd", Locale.US)
        val lf = SimpleDateFormat("EEE dd", Locale.US)
        for (i in 6 downTo 0) {
            val t = System.currentTimeMillis() - i * 86_400_000L
            out.add(Pair(lf.format(Date(t)), p(c).getInt(df.format(Date(t)), 0)))
        }
        return out
    }
}

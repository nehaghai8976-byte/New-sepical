package com.cleanmind.app

import android.content.Context
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Trusted PIN: kisi bharosemand insaan ka set kiya hua PIN. Sirf hash save hota hai. */
object Pin {
    private fun p(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)

    private fun hash(salt: String, pin: String): String =
        MessageDigest.getInstance("SHA-256").digest("$salt:$pin".toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun isSet(c: Context) = !(p(c).getString("pin_hash", "") ?: "").isEmpty()

    fun set(c: Context, pin: String) {
        val salt = System.nanoTime().toString() + Math.random().toString()
        p(c).edit().putString("pin_salt", salt).putString("pin_hash", hash(salt, pin)).apply()
    }

    fun check(c: Context, pin: String): Boolean {
        val salt = p(c).getString("pin_salt", "") ?: ""
        val h = p(c).getString("pin_hash", "") ?: ""
        return h.isNotEmpty() && hash(salt, pin) == h
    }

    private fun dayKey() = "pause_" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    /** Din me max 2 pause. */
    fun canPause(c: Context) = p(c).getInt(dayKey(), 0) < 2
    fun notePause(c: Context) { p(c).edit().putInt(dayKey(), p(c).getInt(dayKey(), 0) + 1).apply() }
}

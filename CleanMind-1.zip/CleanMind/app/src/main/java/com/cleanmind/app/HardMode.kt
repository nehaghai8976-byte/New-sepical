package com.cleanmind.app

import android.app.PendingIntent
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.UserManager

/**
 * Hard Mode = Device Owner. Sirf tab chalta hai jab app ko ADB se device owner banaya ho:
 *   adb shell pm grant com.cleanmind.app android.permission.WRITE_SECURE_SETTINGS
 *   adb shell dpm set-device-owner com.cleanmind.app/.AdminReceiver
 * Strict lock ke time restrictions lagti hain, lock khatam hote hi apne aap hat jati hain.
 */
object HardMode {
    private fun dpm(c: Context) = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    private fun admin(c: Context) = ComponentName(c, AdminReceiver::class.java)
    private fun sp(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)

    fun isOwner(c: Context) = try { dpm(c).isDeviceOwnerApp(c.packageName) } catch (_: Exception) { false }

    private val restrictions = listOf(
        UserManager.DISALLOW_FACTORY_RESET,
        UserManager.DISALLOW_SAFE_BOOT,
        UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES,
        UserManager.DISALLOW_DEBUGGING_FEATURES,
        UserManager.DISALLOW_ADD_USER
    )

    private val stores = listOf(
        "com.heytap.market", "com.oppo.market", "com.oplus.market", "com.nearme.gamecenter", "com.heytap.gamecenter",
        "com.oneplus.market", "com.xiaomi.mipicks", "com.xiaomi.market", "com.sec.android.app.samsungapps",
        "com.huawei.appmarket", "com.hihonor.appmarket", "com.vivo.appstore", "com.bbk.appstore",
        "com.amazon.venezia", "com.transsion.palmstore", "cm.aptoide.pt", "com.apkpure.aegon",
        "com.mobile.indiapp", "com.uptodown", "com.happymod.apk"
    )
    private val moreBrowsers = listOf(
        "org.mozilla.firefox", "org.mozilla.fenix", "com.sec.android.app.sbrowser", "com.microsoft.emmx",
        "com.brave.browser", "com.opera.browser", "com.opera.mini.native", "com.UCMobile.intl",
        "com.duckduckgo.mobile.android", "com.android.browser", "com.mi.globalbrowser", "com.heytap.browser",
        "com.kiwibrowser.browser", "com.vivaldi.browser"
    )

    /** Strict lock chalu hai to restrictions lagao, nahi to hata do. */
    fun sync(c: Context) {
        if (!isOwner(c)) return
        if (Lock.isLocked(c) && Lock.level(c) == 2) apply(c)
        else if (sp(c).getBoolean("hard_applied", false)) release(c)
    }

    fun apply(c: Context) {
        if (!isOwner(c)) return
        val d = dpm(c)
        val a = admin(c)
        try { d.setUninstallBlocked(a, c.packageName, true) } catch (_: Exception) {}
        restrictions.forEach { try { d.addUserRestriction(a, it) } catch (_: Exception) {} }
        try { d.setPermittedAccessibilityServices(a, listOf(c.packageName)) } catch (_: Exception) {}
        if (Build.VERSION.SDK_INT >= 30) {
            try { d.setUserControlDisabledPackages(a, listOf(c.packageName)) } catch (_: Exception) {}
        }
        suspendUnwanted(c)
        sp(c).edit().putBoolean("hard_applied", true).apply()
    }

    fun release(c: Context) {
        if (!isOwner(c)) return
        val d = dpm(c)
        val a = admin(c)
        try { d.setUninstallBlocked(a, c.packageName, false) } catch (_: Exception) {}
        restrictions.forEach { try { d.clearUserRestriction(a, it) } catch (_: Exception) {} }
        try { d.setPermittedAccessibilityServices(a, null) } catch (_: Exception) {}
        if (Build.VERSION.SDK_INT >= 30) {
            try { d.setUserControlDisabledPackages(a, emptyList()) } catch (_: Exception) {}
        }
        val sus = (sp(c).getStringSet("suspended_pkgs", emptySet()) ?: emptySet()).toTypedArray()
        if (sus.isNotEmpty()) { try { d.setPackagesSuspended(a, sus, false) } catch (_: Exception) {} }
        sp(c).edit().putStringSet("suspended_pkgs", emptySet()).putBoolean("hard_applied", false).apply()
    }

    /** Device Owner hata do (sirf lock ke bina). Iske baad app normal uninstall ho sakti hai. */
    @Suppress("DEPRECATION")
    fun dropOwner(c: Context) {
        try { release(c); dpm(c).clearDeviceOwnerApp(c.packageName) } catch (_: Exception) {}
    }

    private fun suspendUnwanted(c: Context) {
        val pm = c.packageManager
        val set = mutableSetOf<String>()
        set += stores
        set += moreBrowsers
        try {
            val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER)
            pm.queryIntentActivities(i, PackageManager.MATCH_ALL).forEach { set.add(it.activityInfo.packageName) }
        } catch (_: Exception) {}
        set += (sp(c).getStringSet("blocked_pkgs", emptySet()) ?: emptySet())
        set.remove("com.android.chrome")
        set.remove(c.packageName)
        val installed = set.filter { try { pm.getApplicationInfo(it, 0); true } catch (_: Exception) { false } }
        if (installed.isEmpty()) return
        try {
            dpm(c).setPackagesSuspended(admin(c), installed.toTypedArray(), true)
            val old = sp(c).getStringSet("suspended_pkgs", emptySet()) ?: emptySet()
            sp(c).edit().putStringSet("suspended_pkgs", old + installed).apply()
        } catch (_: Exception) {}
    }

    /** Device Owner ho to bina dialog ke chupke se uninstall. */
    fun uninstallSilently(c: Context, pkg: String): Boolean {
        if (!isOwner(c)) return false
        return try {
            val pi = PendingIntent.getBroadcast(
                c, 9, Intent("com.cleanmind.app.UNINSTALL_DONE").setPackage(c.packageName),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            c.packageManager.packageInstaller.uninstall(pkg, pi.intentSender)
            true
        } catch (_: Exception) {
            false
        }
    }
}

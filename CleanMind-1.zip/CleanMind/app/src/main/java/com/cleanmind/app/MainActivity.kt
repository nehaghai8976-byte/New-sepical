package com.cleanmind.app

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val BG = 0xFFF3F5FB.toInt()
    private val PURPLE = 0xFF7C6CE6.toInt()
    private val GREEN = 0xFF2E9E57.toInt()
    private val RED = 0xFFB3261E.toInt()
    private val MUTED = 0xFF666B7A.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val mainScreens = listOf("dash", "modes", "stats", "account")
    private val navNames = arrayOf("Dashboard", "Modes", "Analytics", "Account")
    private val H = 3_600_000L
    private val durLabels = arrayOf("1 ghanta", "1 din", "7 din", "15 din", "1 mahina", "2 mahine", "6 mahine", "1 saal")
    private val durMs = longArrayOf(H, 24 * H, 7 * 24 * H, 15 * 24 * H, 30 * 24 * H, 60 * 24 * H, 180 * 24 * H, 365 * 24 * H)
    private val modeLabels = arrayOf("Off", "Sirf Reels/Shorts block", "Poora app block", "10 min reels, phir 5 min break")
    private val appKeys = arrayOf("ig", "fb", "yt")
    private val appNames = arrayOf("Instagram", "Facebook", "YouTube")
    private val socialPkgs = listOf("com.instagram.android", "com.instagram.lite", "com.facebook.katana", "com.facebook.lite",
        "com.snapchat.android", "com.twitter.android", "org.telegram.messenger", "com.reddit.frontpage", "com.whatsapp")
    private val videoPkgs = listOf("com.google.android.youtube", "com.netflix.mediaclient", "in.startv.hotstar",
        "com.amazon.avod.thirdpartyclient", "com.dts.freefireth", "com.pubg.imobile", "com.tencent.ig", "com.supercell.clashofclans")

    private lateinit var headerLeft: TextView
    private lateinit var headerTitle: TextView
    private lateinit var content: FrameLayout
    private val navViews = mutableListOf<TextView>()
    private var screen = "dash"
    private var editIndex = -1
    private var editName = ""
    private var editApps = mutableSetOf<String>()

    private val sp get() = getSharedPreferences("lock", MODE_PRIVATE)
    private val adminCn get() = ComponentName(this, AdminReceiver::class.java)
    private val dpm get() = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val rootLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(28), dp(16), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(PURPLE, 0xFF8EC5EE.toInt()))
        }
        headerLeft = TextView(this).apply {
            textSize = 24f; setTextColor(Color.WHITE); setPadding(dp(12), 0, dp(16), 0)
            setOnClickListener { onHeaderLeft() }
        }
        headerTitle = TextView(this).apply { textSize = 20f; setTextColor(Color.WHITE) }
        header.addView(headerLeft); header.addView(headerTitle)
        content = FrameLayout(this)
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.WHITE) }
        navNames.forEachIndexed { i, n ->
            val tv = TextView(this).apply {
                text = n; gravity = Gravity.CENTER; textSize = 13f
                setPadding(0, dp(14), 0, dp(14))
                setOnClickListener { show(mainScreens[i]) }
            }
            nav.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
            navViews.add(tv)
        }
        rootLayout.addView(header)
        rootLayout.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        rootLayout.addView(nav)
        setContentView(rootLayout)
        show("dash")
    }

    // ---------------- navigation ----------------
    private fun show(name: String) {
        screen = name
        val main = name in mainScreens
        headerLeft.text = if (main) "☰" else "←"
        headerTitle.text = when (name) {
            "dash" -> "Clean Mind"; "modes" -> "Modes"; "stats" -> "Analytics"; "account" -> "Account"
            "perms" -> "Setup"; "settings" -> "Settings"; "reels" -> "Block Reels/Shorts"
            "profile" -> if (editIndex >= 0) "Edit Profile" else "New Profile"
            else -> ""
        }
        val idx = mainScreens.indexOf(name)
        navViews.forEachIndexed { i, tv ->
            tv.setTextColor(if (i == idx) PURPLE else MUTED)
            tv.setTypeface(null, if (i == idx) Typeface.BOLD else Typeface.NORMAL)
        }
        val v: View = when (name) {
            "dash" -> dashScreen(); "modes" -> modesScreen(); "stats" -> statsScreen(); "account" -> accountScreen()
            "perms" -> permsScreen(); "settings" -> settingsScreen(); "reels" -> reelsScreen(); "profile" -> profileScreen()
            else -> TextView(this)
        }
        content.removeAllViews()
        content.addView(v)
    }

    private fun onHeaderLeft() { if (screen in mainScreens) drawer() else show("dash") }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (screen in mainScreens) super.onBackPressed() else show("dash") }

    private fun drawer() {
        val items = arrayOf("Setup / Permissions", "Settings", "Block screen message", "Blocked apps list saaf karo", "About")
        AlertDialog.Builder(this).setItems(items) { _, i ->
            when (i) {
                0 -> show("perms")
                1 -> show("settings")
                2 -> editDialog("Block screen message", "block_msg", "Jaise: Focus karo bhai!") { it }
                3 -> if (!needUnlocked()) { sp.edit().remove("blocked_pkgs").apply(); toast("Saaf ho gaya"); show(screen) }
                4 -> AlertDialog.Builder(this).setTitle("Clean Mind")
                    .setMessage("Apna khud ka blocker. Saara data sirf is phone me save hota hai.").setPositiveButton("OK", null).show()
            }
        }.show()
    }

    // ---------------- helpers ----------------
    private fun needUnlocked(): Boolean {
        if (Lock.isLocked(this)) { toast("Lock ke time badal nahi sakte"); return true }
        return false
    }

    private fun page(build: LinearLayout.() -> Unit): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(28)) }
        col.build()
        return ScrollView(this).apply { addView(col) }
    }

    private fun LinearLayout.card(top: Int = 10, build: LinearLayout.() -> Unit): LinearLayout {
        val c = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(16).toFloat() }
        }
        c.build()
        addView(c, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(14), dp(top), dp(14), 0) })
        return c
    }

    private fun LinearLayout.section(t: String) {
        addView(label(t, 14f, true, MUTED).apply { setPadding(dp(18), dp(18), 0, 0) })
    }

    private fun label(t: String, size: Float = 15f, bold: Boolean = false, color: Int = 0xFF222222.toInt()) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply { text = t; setOnClickListener { onClick() } }

    private fun toggle(t: String, key: String, def: Boolean, locked: Boolean, after: (Boolean) -> Unit = {}): Switch =
        Switch(this).apply {
            text = t; textSize = 15f
            isChecked = sp.getBoolean(key, def)
            isEnabled = !locked
            setOnCheckedChangeListener { _, c -> sp.edit().putBoolean(key, c).apply(); after(c) }
        }

    private fun list(s: String?): List<String> = (s ?: "").split(",", "\n").map { it.trim() }.filter { it.isNotEmpty() }

    private fun remaining(ms: Long) = "${ms / 86400000} din ${(ms % 86400000) / 3600000} ghante ${(ms % 3600000) / 60000} min"

    private fun accOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/${BlockerService::class.java.name}")
    }

    private fun normalizeSites(s: String) = list(s).map {
        it.lowercase().removePrefix("https://").removePrefix("http://").removePrefix("www.").substringBefore("/")
    }.filter { it.contains('.') }.joinToString(",")

    private fun editDialog(title: String, key: String, hint: String, normalize: (String) -> String) {
        if (needUnlocked()) return
        val et = EditText(this).apply {
            setText(sp.getString(key, "")); this.hint = hint; minLines = 3; gravity = Gravity.TOP
        }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("Save") { _, _ ->
                sp.edit().putString(key, normalize(et.text.toString())).apply(); show(screen)
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------------- profiles storage ----------------
    private fun loadProfiles(): JSONArray = try { JSONArray(sp.getString("profiles", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
    private fun saveProfiles(a: JSONArray) { sp.edit().putString("profiles", a.toString()).apply() }

    private fun installedApps(): List<Pair<String, String>> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map { Pair(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
    }

    private fun startTemplate(name: String, pkgs: List<String>) {
        if (needUnlocked()) return
        editIndex = -1
        editName = name
        editApps = pkgs.filter { packageManager.getLaunchIntentForPackage(it) != null }.toMutableSet()
        show("profile")
    }

    private fun saveEdit() {
        val arr = loadProfiles()
        val o = if (editIndex >= 0) arr.getJSONObject(editIndex) else JSONObject().put("active", false)
        o.put("name", editName)
        val apps = JSONArray()
        editApps.forEach { apps.put(it) }
        o.put("apps", apps)
        if (editIndex < 0) arr.put(o)
        saveProfiles(arr)
    }

    // ---------------- DASHBOARD ----------------
    private fun dashScreen(): View {
        val locked = Lock.isLocked(this)
        return page {
            val ready = dpm.isAdminActive(adminCn) && accOn() && DnsVpnService.active
            if (!ready) card {
                addView(label("⚠ Setup adhura hai", 16f, true, RED))
                addView(label("Device Admin, Accessibility aur VPN ON karo. Yahan tap karo.", 13f, false, MUTED))
                setOnClickListener { show("perms") }
            }
            if (locked) card {
                val lvl = if (Lock.level(this@MainActivity) == 2) "Strict" else "Lock"
                addView(label("🔒 $lvl Mode ON", 16f, true, GREEN))
                addView(label(remaining(Lock.remainingMs(this@MainActivity)) + " baaki", 13f, false, MUTED))
            }
            if (locked) card {
                if (Lock.isPaused(this@MainActivity)) {
                    addView(label("⏸ Pause chal raha hai: ${Lock.pauseLeft(this@MainActivity) / 60000 + 1} min baaki", 15f, true, RED))
                    addView(label("Accessibility band ho chuki hai. Payment ke baad Setup me wapas ON karo.", 13f, false, MUTED))
                } else {
                    addView(label("Payment ya emergency?", 15f, true))
                    addView(label("Trusted PIN se 15 min ka pause (din me 2 baar).", 13f, false, MUTED))
                    addView(btn("PIN dalo (pause)") { pauseDialog() })
                    addView(btn("Lock khatam karo (Trusted PIN)") { endLockDialog() })
                }
            }
            card {
                addView(label("${list(sp.getString("custom_sites", "")).size}", 24f, true))
                addView(label("Sites Blocked (adult sites DNS se pehle se block)", 13f, false, MUTED))
                addView(btn("Configure") { editDialog("Block karne wali sites", "custom_sites", "example.com, site2.com") { normalizeSites(it) } })
            }
            card {
                addView(label("${list(sp.getString("custom_allow", "")).size}", 24f, true))
                addView(label("Allowed sites (net banking jaisi sites, keyword/DNS se rukti nahi). Bade banks pehle se allowed hain.", 13f, false, MUTED))
                addView(btn("Configure") { editDialog("Allowed sites", "custom_allow", "mybank.com, site2.com") { normalizeSites(it) } })
            }
            card {
                addView(toggle("Keywords Blocked", "kw_on", true, locked))
                addView(label("${list(sp.getString("custom_kw", "")).size} custom keywords", 13f, false, MUTED))
                addView(btn("Configure") { editDialog("Custom keywords", "custom_kw", "word1, word2") { it } })
            }
            card {
                addView(toggle("Block Adult Content", "adult_on", true, locked))
                addView(label("Adult keywords + DNS filter (VPN ON rakho)", 13f, false, MUTED))
            }
            card {
                val on = appKeys.any { sp.getInt("app_$it", 0) != 0 }
                val s = Switch(this@MainActivity)
                s.text = "Block Reels/Shorts"
                s.textSize = 15f
                s.isChecked = on
                s.isEnabled = !locked
                s.setOnCheckedChangeListener { _, c ->
                    val e = sp.edit()
                    for (k in appKeys) {
                        if (c && sp.getInt("app_$k", 0) == 0) e.putInt("app_$k", 1)
                        if (!c) e.putInt("app_$k", 0)
                    }
                    e.apply()
                }
                addView(s)
                addView(label("Instagram, Facebook, YouTube", 13f, false, MUTED))
                addView(btn("Configure") { show("reels") })
            }

            section("Profiles")
            card {
                addView(label("＋  ADD A NEW PROFILE", 15f, true, PURPLE))
                setOnClickListener {
                    if (!needUnlocked()) { editIndex = -1; editName = ""; editApps = mutableSetOf(); show("profile") }
                }
            }
            val arr = loadProfiles()
            for (idx in 0 until arr.length()) {
                val o = arr.getJSONObject(idx)
                val apps = o.optJSONArray("apps") ?: JSONArray()
                val active = o.optBoolean("active")
                card {
                    addView(label("🚫 " + o.optString("name"), 16f, true))
                    val icons = LinearLayout(this@MainActivity)
                    for (j in 0 until minOf(apps.length(), 6)) {
                        try {
                            val iv = ImageView(this@MainActivity)
                            iv.setImageDrawable(packageManager.getApplicationIcon(apps.getString(j)))
                            icons.addView(iv, LinearLayout.LayoutParams(dp(30), dp(30)).apply { setMargins(0, dp(8), dp(8), 0) })
                        } catch (_: Exception) {}
                    }
                    addView(icons)
                    addView(label(if (active) "● ACTIVE: ye apps abhi block hain" else "Inactive", 12f, false, if (active) GREEN else MUTED))
                    val row = LinearLayout(this@MainActivity)
                    row.addView(btn(if (active) "Deactivate" else "Activate") {
                        if (active && needUnlocked()) return@btn
                        o.put("active", !active); saveProfiles(arr); show("dash")
                    })
                    row.addView(btn("Edit") {
                        if (needUnlocked()) return@btn
                        editIndex = idx
                        editName = o.optString("name")
                        editApps = (0 until apps.length()).map { apps.getString(it) }.toMutableSet()
                        show("profile")
                    })
                    row.addView(btn("Delete") {
                        if (needUnlocked()) return@btn
                        arr.remove(idx); saveProfiles(arr); show("dash")
                    })
                    addView(row)
                }
            }

            section("Profile Templates")
            card {
                addView(label("Social Media", 16f, true))
                addView(label("Instagram, Facebook, Snapchat, X, Telegram, Reddit, WhatsApp", 13f, false, MUTED))
                setOnClickListener { startTemplate("Social Media", socialPkgs) }
            }
            card {
                addView(label("Video & Games", 16f, true))
                addView(label("YouTube, Netflix, Hotstar, Prime Video, games", 13f, false, MUTED))
                setOnClickListener { startTemplate("Video & Games", videoPkgs) }
            }
        }
    }

    // ---------------- PROFILE EDITOR ----------------
    private fun profileScreen(): View = page {
        val et = EditText(this@MainActivity).apply { hint = "Profile ka naam"; setText(editName) }
        card { addView(et) }
        section("Block karne wale apps chuno")
        card {
            installedApps().forEach { (lab, pkg) ->
                val cb = CheckBox(this@MainActivity)
                cb.text = lab
                cb.isChecked = pkg in editApps
                cb.setOnCheckedChangeListener { _, c -> if (c) editApps.add(pkg) else editApps.remove(pkg) }
                addView(cb)
            }
        }
        card {
            addView(btn("Save") {
                editName = et.text.toString().trim().ifEmpty { "Profile" }
                saveEdit(); show("dash")
            })
        }
    }

    // ---------------- MODES ----------------
    private fun modesScreen(): View = page {
        val locked = Lock.isLocked(this@MainActivity)
        val lvl = Lock.level(this@MainActivity)
        card {
            addView(label("Normal Mode", 17f, true))
            addView(label(if (!locked) "● Active" else "Lock khatam hone par wapas aayega", 12f, false, if (!locked) GREEN else MUTED))
            addView(label("Changes aur uninstall khule hain.", 13f, false, MUTED))
        }
        card {
            addView(label("Lock Mode", 17f, true))
            if (locked && lvl == 1) addView(label("● Active: " + remaining(Lock.remainingMs(this@MainActivity)) + " baaki", 12f, false, GREEN))
            addView(label("Profiles, toggles aur settings set time tak badal nahi sakte.", 13f, false, MUTED))
            addView(btn("ACTIVATE") { chooseDuration(1) }.apply { isEnabled = !locked })
        }
        card {
            addView(label("Strict Mode", 17f, true))
            if (locked && lvl == 2) addView(label("● Active: " + remaining(Lock.remainingMs(this@MainActivity)) + " baaki", 12f, false, GREEN))
            addView(label("Lock Mode + phone Settings, uninstall, VPN/Accessibility band karna sab blocked.", 13f, false, MUTED))
            addView(btn("ENABLE") { chooseDuration(2) }.apply { isEnabled = !locked })
        }
        card {
            addView(label("Trusted PIN", 17f, true))
            addView(label(if (Pin.isSet(this@MainActivity)) "● PIN set hai" else "PIN abhi set nahi", 12f, false, if (Pin.isSet(this@MainActivity)) GREEN else RED))
            addView(label("Kisi bharosemand dost/ghar waale se PIN daalwao. Tujhe pata nahi hona chahiye. Payment jaisi zaroorat me wahi PIN dalega to 15 min ka pause milega.", 13f, false, MUTED))
            addView(btn(if (Pin.isSet(this@MainActivity)) "PIN badlo" else "PIN set karo") { setPinDialog() }.apply { isEnabled = !locked })
        }
    }

    private fun chooseDuration(level: Int) {
        if (Lock.isLocked(this)) return
        if (!Pin.isSet(this)) { setPinDialog { chooseDuration(level) }; return }
        if (level == 2 && !(dpm.isAdminActive(adminCn) && accOn() && DnsVpnService.active)) {
            AlertDialog.Builder(this).setTitle("Pehle setup karo")
                .setMessage("Strict Mode ke liye Device Admin, Accessibility aur VPN teeno ON hone chahiye.")
                .setPositiveButton("Setup") { _, _ -> show("perms") }
                .setNegativeButton("Cancel", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle(if (level == 2) "Strict Mode kitne time ke liye?" else "Lock Mode kitne time ke liye?")
            .setItems(durLabels) { _, i ->
                AlertDialog.Builder(this).setTitle("Pakka?")
                    .setMessage("${durLabels[i]} tak lock rahega. Undo nahi hoga.")
                    .setPositiveButton("Haan, lock karo") { _, _ -> Lock.start(this, durMs[i], level); HardMode.sync(this); show("modes") }
                    .setNegativeButton("Ruk", null).show()
            }.show()
    }

    private fun pinInput() = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        hint = "4-6 digit PIN"
    }

    private fun setPinDialog(then: () -> Unit = {}) {
        if (needUnlocked()) return
        val et = pinInput()
        AlertDialog.Builder(this).setTitle("Trusted PIN set karo")
            .setMessage("Ye PIN kisi bharosemand dost ya ghar waale se daalwao. Tujhe pata nahi hona chahiye, warna lock ka matlab nahi.")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                val v = et.text.toString()
                if (v.length in 4..6) { Pin.set(this, v); toast("PIN set ho gaya"); then() } else toast("4-6 digit chahiye")
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun endLockDialog() {
        val et = pinInput()
        AlertDialog.Builder(this).setTitle("Lock khatam karne ke liye Trusted PIN").setView(et)
            .setPositiveButton("Khatam karo") { _, _ ->
                if (Pin.check(this, et.text.toString())) {
                    Lock.end(this); HardMode.sync(this); toast("Lock khatam"); show(screen)
                } else toast("Galat PIN")
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun dropOwnerDialog() {
        if (needUnlocked()) return
        AlertDialog.Builder(this).setTitle("Device Owner hatao?")
            .setMessage("Hard Mode band ho jayega aur app normal uninstall ho sakti hai.")
            .setPositiveButton("Haan") { _, _ -> HardMode.dropOwner(this); toast("Hat gaya"); show(screen) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun pauseDialog() {
        if (!Pin.canPause(this)) { toast("Aaj ke 2 pause ho chuke"); return }
        val et = pinInput()
        AlertDialog.Builder(this).setTitle("Trusted PIN").setView(et)
            .setPositiveButton("Pause") { _, _ ->
                if (Pin.check(this, et.text.toString())) {
                    Pin.notePause(this)
                    Lock.startPause(this, 15 * 60_000L)
                    toast("15 min pause. Accessibility band ho rahi hai")
                    show(screen)
                } else toast("Galat PIN")
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------------- ANALYTICS ----------------
    private fun statsScreen(): View = page {
        val last = Stats.last7(this@MainActivity)
        val maxV = maxOf(last.maxOf { it.second }, 1)
        card {
            addView(label("${last.last().second}", 30f, true))
            addView(label("Aaj blocked attempts", 13f, false, MUTED))
        }
        card {
            addView(label("Pichle 7 din", 15f, true))
            last.forEach { (d, n) ->
                addView(label("$d  ${"█".repeat(n * 12 / maxV)}  $n", 13f).apply {
                    typeface = Typeface.MONOSPACE; setPadding(0, dp(6), 0, 0)
                })
            }
        }
        card {
            val blocked = (sp.getStringSet("blocked_pkgs", emptySet()) ?: emptySet()).size
            addView(label("🚫 Blocked apps: $blocked", 14f))
            addView(label("📋 Profiles: ${loadProfiles().length()}", 14f))
        }
    }

    // ---------------- ACCOUNT ----------------
    private fun accountScreen(): View = page {
        card {
            gravity = Gravity.CENTER_HORIZONTAL
            addView(label("👤", 40f))
            addView(label("Guest", 18f, true))
            addView(label("Login ya premium ki zaroorat nahi. Saara data sirf is phone me save hota hai.", 13f, false, MUTED))
        }
        card { addView(label("Clean Mind v1.0", 13f, false, MUTED)) }
    }

    // ---------------- SETUP ----------------
    private fun permsScreen(): View = page {
        val locked = Lock.isLocked(this@MainActivity)
        val a = dpm.isAdminActive(adminCn); val c = accOn(); val v = DnsVpnService.active
        fun t(x: Boolean) = if (x) "✅" else "❌"
        card {
            addView(label("${t(a)} Device Admin (uninstall rokta hai)", 15f))
            addView(label("${t(c)} Accessibility (blockers)", 15f))
            addView(label("${t(v)} Site Blocker (VPN/DNS)", 15f))
        }
        card {
            addView(label("${t(AccessGuard.canWrite(this@MainActivity))} Auto payment mode (ADB permission)", 15f))
            addView(label("GPay/Paytm khulte hi Accessibility 3 min ke liye khud band, phir khud ON. Ek baar ye command chalani padti hai:", 12f, false, MUTED))
            addView(label("adb shell pm grant com.cleanmind.app android.permission.WRITE_SECURE_SETTINGS", 12f).apply {
                setTextIsSelectable(true); typeface = Typeface.MONOSPACE
            })
        }
        card {
            addView(btn("1. Device Admin ON karo") {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminCn)
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Uninstall rokne ke liye"))
            }.apply { isEnabled = !locked })
            addView(btn("2. Accessibility ON karo") {
                toast("Clean Mind Blocker ko ON karo")
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }.apply { isEnabled = !locked })
            addView(btn("3. Site Blocker (VPN) ON karo") {
                val i = VpnService.prepare(this@MainActivity)
                if (i != null) startActivityForResult(i, 1) else startVpn()
            }.apply { isEnabled = !locked || !v })
            addView(label("Android 13+: Settings → Apps → Clean Mind → ⋮ → Allow restricted settings (pehle).", 12f, false, MUTED))
        }
        card {
            addView(label("Phone app ko khud band na kare (Oppo/Realme)", 15f, true))
            addView(label("Lock lagane se PEHLE ye 3 kaam karo. Lock ke baad ye screens band ho jati hain.", 12f, false, MUTED))
            addView(btn("1. Battery: hamesha background me chalne do") {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                } catch (_: Exception) { openAppDetails() }
            }.apply { isEnabled = !locked })
            addView(btn("2. Oppo Auto-start / Battery settings kholo") { openOppoSettings() }.apply { isEnabled = !locked })
            addView(label("Wahan Clean Mind ke liye: Auto launch ON, Allow background activity ON, Battery Unrestricted. Recent apps me Clean Mind ke card ko lock karo.", 12f, false, MUTED))
        }
        card {
            val owner = HardMode.isOwner(this@MainActivity)
            addView(label("${t(owner)} Hard Mode (Device Owner)", 15f, true))
            addView(label("Strict lock ke time: app uninstall nahi hogi, factory reset / safe mode / USB debugging band, doosre browsers aur stores suspend, adult apps chupke se uninstall. Lock khatam hote hi sab wapas khul jata hai.", 12f, false, MUTED))
            if (!owner) {
                addView(label("PC se ek baar (phone me koi Google account ya Dual app nahi hona chahiye):", 12f, false, MUTED))
                addView(label("adb shell pm grant com.cleanmind.app android.permission.WRITE_SECURE_SETTINGS", 11f).apply {
                    setTextIsSelectable(true); typeface = Typeface.MONOSPACE
                })
                addView(label("adb shell dpm set-device-owner com.cleanmind.app/.AdminReceiver", 11f).apply {
                    setTextIsSelectable(true); typeface = Typeface.MONOSPACE
                })
            } else {
                addView(btn("Device Owner hatao (lock ke bina)") { dropOwnerDialog() }.apply { isEnabled = !locked })
            }
        }
    }

    private fun openAppDetails() {
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (_: Exception) {}
    }

    private fun openOppoSettings() {
        val tries = listOf(
            Intent().setClassName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
            Intent().setClassName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"),
            Intent().setClassName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"),
            Intent().setClassName("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgauge.PowerUsageModelActivity")
        )
        for (i in tries) {
            try { startActivity(i); return } catch (_: Exception) {}
        }
        toast("Seedha screen nahi khuli. App info me Battery aur Auto-start dekho.")
        openAppDetails()
    }

    private fun startVpn() {
        sp.edit().putBoolean("vpn_on", true).apply()
        startService(Intent(this, DnsVpnService::class.java))
        content.postDelayed({ show(screen) }, 600)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 1 && res == RESULT_OK) startVpn()
    }

    // ---------------- SETTINGS ----------------
    private fun settingsScreen(): View = page {
        val locked = Lock.isLocked(this@MainActivity)
        card {
            addView(label("Blocking Options", 15f, true))
            addView(toggle("Block Unsupported Browsers (sirf Chrome)", "opt_browsers", true, locked))
            addView(toggle("Block 13+ apps (Play Store)", "opt_play", true, locked))
            addView(toggle("Block dusre app stores (App Market, GetApps etc.)", "opt_stores", true, locked))
            addView(toggle("Block naya Insta/FB account banana", "opt_signup", true, locked))
        }
        card {
            addView(label("Strict options (lock ke time chalte hain)", 15f, true))
            addView(toggle("Block Split Screen", "opt_split", true, locked))
            addView(toggle("Block Power Off", "opt_power", false, locked))
            addView(toggle("Block Recent Apps", "opt_recents", false, locked))
            addView(toggle("Block Battery Settings", "opt_battery", true, locked))
        }
    }

    // ---------------- REELS CONFIG ----------------
    private fun reelsScreen(): View = page {
        val locked = Lock.isLocked(this@MainActivity)
        appKeys.forEachIndexed { i, k ->
            card {
                addView(label(appNames[i], 16f, true))
                val rg = RadioGroup(this@MainActivity)
                modeLabels.forEachIndexed { m, l ->
                    rg.addView(RadioButton(this@MainActivity).apply { text = l; id = 300 + m; isEnabled = !locked })
                }
                rg.check(300 + sp.getInt("app_$k", 0))
                rg.setOnCheckedChangeListener { _, id -> sp.edit().putInt("app_$k", id - 300).apply() }
                addView(rg)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        AccessGuard.ensure(this)
        WatchdogJob.schedule(this)
        HardMode.sync(this)
        if (screen != "profile") show(screen)
    }
}

package com.cleanmind.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Payment window khatam: Accessibility wapas ON. */
class PayWindowReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AccessGuard.ensure(context)
    }
}

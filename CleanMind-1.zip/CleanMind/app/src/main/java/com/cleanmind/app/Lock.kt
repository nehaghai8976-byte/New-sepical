package com.cleanmind.app

import android.content.Context
import android.os.SystemClock
import android.provider.Settings

/** Lock timer. level 1 = Lock Mode (app settings lock), level 2 = Strict Mode (Settings/uninstall/VPN sab lock). */
object Lock {
    private fun p(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)
    private fun boot(c: Context) = Settings.Global.getInt(c.contentResolver, Settings.Global.BOOT_COUNT, -1)

    fun start(c: Context, ms: Long, level: Int) {
        if (isLocked(c)) return
        p(c).edit()
            .putLong("wallEnd", System.currentTimeMillis() + ms)
            .putLong("elapsedEnd", SystemClock.elapsedRealtime() + ms)
            .putInt("boot", boot(c))
            .putInt("level", level)
            .apply()
    }

    fun remainingMs(c: Context): Long {
        val s = p(c)
        var left = s.getLong("wallEnd", 0) - System.currentTimeMillis()
        if (s.getInt("boot", -2) == boot(c)) {
            left = maxOf(left, s.getLong("elapsedEnd", 0) - SystemClock.elapsedRealtime())
        }
        return maxOf(left, 0)
    }

    fun isLocked(c: Context) = remainingMs(c) > 0

    /** Trusted PIN se lock jaldi khatam. */
    fun end(c: Context) { p(c).edit().putLong("wallEnd", 0).putLong("elapsedEnd", 0).apply() }
    fun level(c: Context) = p(c).getInt("level", 2)

    // Trusted PIN se milne wala chhota pause (payment ke liye). Pause me strict guards band.
    fun startPause(c: Context, ms: Long) {
        p(c).edit()
            .putLong("pauseWall", System.currentTimeMillis() + ms)
            .putLong("pauseElapsed", SystemClock.elapsedRealtime() + ms)
            .putInt("pauseBoot", boot(c))
            .apply()
    }

    fun pauseLeft(c: Context): Long {
        val s = p(c)
        var left = s.getLong("pauseWall", 0) - System.currentTimeMillis()
        if (s.getInt("pauseBoot", -2) == boot(c)) {
            left = maxOf(left, s.getLong("pauseElapsed", 0) - SystemClock.elapsedRealtime())
        }
        return maxOf(left, 0)
    }

    fun isPaused(c: Context) = pauseLeft(c) > 0
    fun isStrict(c: Context) = isLocked(c) && level(c) == 2 && !isPaused(c)
}

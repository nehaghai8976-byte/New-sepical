package com.cleanmind.app

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.VpnService

/** Har ~15 min: agar phone (Oppo/ColorOS) ne app ya VPN band kar diya to wapas chalu karne ki koshish. */
class WatchdogJob : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        try {
            AccessGuard.ensure(this)
            HardMode.sync(this)
            val wanted = getSharedPreferences("lock", MODE_PRIVATE).getBoolean("vpn_on", false)
            if (wanted && !DnsVpnService.active && VpnService.prepare(this) == null) {
                startService(Intent(this, DnsVpnService::class.java))
            }
        } catch (_: Exception) {}
        return false
    }

    override fun onStopJob(params: JobParameters?) = false

    companion object {
        fun schedule(c: Context) {
            try {
                val js = c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
                if (js.allPendingJobs.any { it.id == 42 }) return
                js.schedule(
                    JobInfo.Builder(42, ComponentName(c, WatchdogJob::class.java))
                        .setPeriodic(15 * 60 * 1000L).setPersisted(true).build()
                )
            } catch (_: Exception) {}
        }
    }
}

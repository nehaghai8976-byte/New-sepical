package com.cleanmind.app

import android.content.Context

/** Net banking / payment jaisi sites: inpe keyword block nahi, aur DNS bhi bina adult filter ke. */
object Allow {
    val bankDomains = listOf(
        "kotak.com", "hdfcbank.com", "icicibank.com", "sbi.co.in", "onlinesbi.sbi", "axisbank.com",
        "yesbank.in", "idfcfirstbank.com", "indusind.com", "bankofbaroda.in", "pnbindia.in",
        "canarabank.com", "unionbankofindia.co.in", "bankofindia.co.in", "federalbank.co.in",
        "rblbank.com", "aubank.in", "paytm.com", "phonepe.com", "npci.org.in", "razorpay.com",
        "billdesk.com", "irctc.co.in", "incometax.gov.in", "uidai.gov.in"
    )

    private fun custom(c: Context): List<String> =
        (c.getSharedPreferences("lock", Context.MODE_PRIVATE).getString("custom_allow", "") ?: "")
            .split(",", "\n").map { it.trim().lowercase() }.filter { it.length >= 3 }

    fun domainAllowed(c: Context, name: String): Boolean {
        val n = name.lowercase().trimEnd('.')
        return (bankDomains + custom(c)).any { n == it || n.endsWith(".$it") }
    }

    fun textAllowed(c: Context, head: String): Boolean = (bankDomains + custom(c)).any { head.contains(it) }
}
